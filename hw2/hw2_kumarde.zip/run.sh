rm *.png
matlab -nodisplay -nodesktop -nosplash -r "addpath('q2'), addpath('q3'), q2b, nb_train, nb_test, q3c" 
exit
